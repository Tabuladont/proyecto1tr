package com.lusafolg.proyectoprimertrimestre

interface OnClickListener {

    fun onClick(entrada: Entrada, position:Int)

}