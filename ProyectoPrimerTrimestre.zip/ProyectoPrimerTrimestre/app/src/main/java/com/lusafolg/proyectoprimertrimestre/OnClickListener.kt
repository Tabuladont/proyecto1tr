package com.lusafolg.proyectoprimertrimestre

interface OnClickListener {

    fun onClick(entrada: Entrada, position:Int)

    fun onLongClick(entrada: Entrada)

}