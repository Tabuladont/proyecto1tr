package com.lusafolg.proyectoprimertrimestre

data class Usuario(val id:Int, val nombre:String, val pass:String, val descripcion:String, val foto:String)
