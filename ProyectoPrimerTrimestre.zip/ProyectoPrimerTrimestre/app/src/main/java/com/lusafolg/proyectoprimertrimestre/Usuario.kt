package com.lusafolg.proyectoprimertrimestre

data class Usuario(val nombre:String, val pass:String)
