package com.lusafolg.proyectoprimertrimestre

data class Ajuste(val texto:String)
