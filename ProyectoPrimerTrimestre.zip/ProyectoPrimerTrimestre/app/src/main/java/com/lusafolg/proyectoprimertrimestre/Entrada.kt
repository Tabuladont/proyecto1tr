package com.lusafolg.proyectoprimertrimestre

data class Entrada(val id:Int, val nombre:String, val descripcion:String, val habitat:String,val foto:String, val usuario: Usuario)
